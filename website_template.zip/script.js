document.querySelector('.cta-btn').addEventListener('click', () => {
  alert('Thanks for exploring!');
});
